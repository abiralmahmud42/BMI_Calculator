﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BMI_Calculator
{
    public partial class BMI_Calculation : Form
    {
        public BMI_Calculation()
        {
            InitializeComponent();
        }

        private void CalculateBMI(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                label5.Text = "*Please enter your height";
            }
            else if (textBox3.Text == "")
            {
                label5.Text = "*Please enter your weight";
            }
            else if (comboBox1.SelectedItem == null)
            {
                label5.Text = "*Please select unit of your height";
            }
            else if (comboBox2.SelectedItem == null)
            {
                label5.Text = "*Please select unit of your weight";
            }
            else
            {
                double height = Convert.ToDouble(textBox2.Text);
                double weight = Convert.ToDouble(textBox3.Text);
                if (comboBox1.SelectedItem == "Feet")
                {
                    height = height * 0.3048;
                }
                if (comboBox2.SelectedItem == "Pounds")
                {
                    weight = weight * 0.453592;
                }
                textBox5.Text = "Your height is " + Convert.ToString(Math.Round(height, 4)) + " meters" +
                "and weight is " + Convert.ToString(Math.Round(weight, 4)) + " kg";
                double bmi = weight / (height * height);
                textBox4.Text = Convert.ToString(bmi);
                if (bmi < 18.5)
                {
                    textBox6.Text = "You are Underweighted";
                }
                else if (bmi > 18.5 && bmi <= 24.9)
                {
                    textBox6.Text = "You have normal weight";
                }
                else if (bmi >= 25 && bmi <= 29.9)
                {
                    textBox6.Text = "You are overweighted";
                }
                else
                {
                    textBox6.Text = "You have obesity";
                }
            }
        }
    }
}
